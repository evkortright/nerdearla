package com.example.busqueda;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.client.RestTemplate;
import co.elastic.apm.api.CaptureSpan;
import org.springframework.web.bind.annotation.RequestParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@SpringBootApplication
public class BusquedaApplication {
   Logger logger = LoggerFactory.getLogger(BusquedaApplication.class);

   @CaptureSpan(value="elasticsearch")
   private String getElasticsearch(String terminos) {
       logger.info("Buscando " + terminos + " en Elasticsearch");
       RestTemplate rest = new RestTemplate();
       return rest.getForObject("http://server1:9200/clientes/_search?q=nombre:" + terminos + "&filter_path=hits.hits", String.class);
   }

   @CrossOrigin
   @GetMapping("/busca")
   public String busca(@RequestParam(value = "terminos",
       defaultValue = "*") String terminos) {
       System.out.println("terminos: " + terminos);
       return getElasticsearch(terminos);
   }

   public static void main(String[] args) {
       SpringApplication.run(BusquedaApplication.class, args);
   }
}
